// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2024-2026 Friehub. All rights reserved.
// Commercial use requires a separate license: https://friehub.com/licensing

//! Severity declarations, the tier ladder, and advisory registries.
//!
//! Everything report-shaped lives here, not in the engine or the app:
//!
//! - [`Severity`] - the ranking type used by every reporter surface.
//! - [`SinkRole`] - what a sink does with the data it receives, plus the
//!   default role->tier map ([`SinkRole::default_level`]) and the stable
//!   reporting tag ([`SinkRole::tag`]). The engine re-exports the type and
//!   emits it on findings; it holds zero tier strings (D4).
//! - [`RuleAdvisory`] / [`RuleEntry`] - per-language rule registries
//!   (`LanguageSpec::known_rule_registry`): each language declares the
//!   severity and message templates for the rules it owns.
//! - [`generic_rule_advisory`] - the cross-cutting fallback for any rule no
//!   language declares (preserves the historical "Policy violation" shape).
//! - [`taint_advisory`] - the cross-cutting class x role ranking for dataflow
//!   findings.

use serde::{Deserialize, Serialize};

/// Advisory severity ranking.
#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Severity {
    Critical,
    Warning,
    Info,
}

impl Severity {
    #[must_use]
    pub fn meets_threshold(&self, threshold: Severity) -> bool {
        match (self, threshold) {
            (Severity::Critical, _)
            | (Severity::Info, Severity::Info)
            | (Severity::Warning, Severity::Warning | Severity::Info) => true,
            (Severity::Warning, Severity::Critical) | (Severity::Info, _) => false,
        }
    }

    /// Parse a level name; unknown names rank as [`Severity::Info`].
    pub fn parse(level: &str) -> Severity {
        match level {
            "critical" => Severity::Critical,
            "warning" => Severity::Warning,
            _ => Severity::Info,
        }
    }
}

/// What the sink does with the value flowing into it.
///
/// Two sinks that both "receive tainted data" are not equally dangerous:
/// `eval(userInput)` executes it, `db.query({ where: { id } })` controls
/// row selection, and `res.json(userInput)` merely reflects it back, the
/// last is normally not a bug at all unless the client renders it
/// unescaped. Classifying by role lets consumers rank findings by what
/// the sink does instead of treating every flow as Critical.
///
/// Since Phase 6.3 the default pack stores each sink's role name
/// directly (the pack generator maps its vocabulary labels onto these
/// roles at generation time); this crate owns the role type, the
/// default role->tier ladder and the stable reporting tag.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SinkRole {
    /// Data is interpreted as code: eval, exec, deserialize, template
    /// engines, SQL/NoSQL/LDAP strings. Highest severity.
    Execution,
    /// Data selects or reads a resource (IDOR-class query payloads, path
    /// traversal). Access-control concern, ranked below execution.
    Resource,
    /// Data is written to persistent storage (KV put, file write).
    Storage,
    /// Data goes into a cryptographic operation (sign, cipher, hash).
    Crypto,
    /// Data is reflected into an HTTP response. Usually not a bug by
    /// itself, review-level, the client-side rendering decides.
    Response,
    /// Cross-site scripting (DOM, Reflected, Stored). Client-side code
    /// execution in the browser context.
    Xss,
    /// Data enters a validation/verification routine (jwt.verify,
    /// `.test()`, comparators). Consuming tainted data is these APIs'
    /// *job*; a finding here is almost always noise.
    Validation,
    /// Unknown or unlabeled sink, keep the conservative default.
    #[default]
    Other,
}

impl SinkRole {
    /// The default tier for this role: the ladder lives here (D4), not in
    /// the engine. Consumers map it onto their own reporting policy.
    #[must_use]
    pub fn default_level(&self) -> Severity {
        match self {
            SinkRole::Execution | SinkRole::Other => Severity::Critical,
            SinkRole::Resource | SinkRole::Storage | SinkRole::Crypto | SinkRole::Xss => {
                Severity::Warning
            }
            SinkRole::Response | SinkRole::Validation => Severity::Info,
        }
    }

    /// Stable tag for reporting (SARIF properties, CLI JSON).
    #[must_use]
    pub fn tag(&self) -> &'static str {
        match self {
            SinkRole::Execution => "execution",
            SinkRole::Resource => "resource",
            SinkRole::Storage => "storage",
            SinkRole::Crypto => "crypto",
            SinkRole::Response => "response",
            SinkRole::Validation => "validation",
            SinkRole::Xss => "xss",
            SinkRole::Other => "other",
        }
    }
}

/// CWE id for a taint finding, resolved from the sink's role and its
/// semantic label slug. Both are known precisely at emit time; the role
/// alone is not (`Execution` spans code, command, SQL/LDAP injection
/// and deserialization), so a pair that pins no single class returns
/// `None`: an honest gap beats a mis-tagged id.
#[must_use]
pub fn taint_cwe(role: SinkRole, label: Option<&str>) -> Option<&'static str> {
    match (role, label) {
        (SinkRole::Xss, _) => Some("CWE-79"),
        (SinkRole::Response, Some("redirect")) => Some("CWE-601"),
        // OpenRedirect sinks serialize under the Resource role with the
        // "redirect" label (role_map maps OpenRedirect -> Resource); the
        // Response arm above is the header/response-channel redirect.
        (SinkRole::Resource, Some("redirect")) => Some("CWE-601"),
        (SinkRole::Resource, Some("traversal")) => Some("CWE-22"),
        (SinkRole::Execution, Some("sql")) => Some("CWE-89"),
        (SinkRole::Execution, Some("nosql")) => Some("CWE-947"),
        (SinkRole::Execution, Some("ldap")) => Some("CWE-90"),
        (SinkRole::Execution, Some("command")) => Some("CWE-78"),
        (SinkRole::Execution, Some("deserialize")) => Some("CWE-502"),
        (SinkRole::Execution, Some("eval")) => Some("CWE-94"),
        // CodeExecution sinks (eval/exec/compile) serialize the slug
        // "execution"; it is distinct from the bare-Execution role (no
        // label), which spans command/SQL/code and stays None.
        (SinkRole::Execution, Some("execution")) => Some("CWE-94"),
        (SinkRole::Execution, Some("ssrf")) => Some("CWE-918"),
        _ => None,
    }
}

/// CWE id for a built-in checker rule id. Memory-safety rules map to
/// their canonical CWEs; crypto-policy rules map where the class is
/// unambiguous. Learned bundle rule ids and guard/policy rules with no
/// single class return `None` - the bundle pattern overlay carries the
/// corpus-authored CWE for those.
#[must_use]
pub fn checker_rule_cwe(rule: &str) -> Option<&'static str> {
    Some(match rule {
        "weak_hash" | crate::rules::WEAK_HASH_WRAPPER | "learned_broken_hash_func" => "CWE-328",
        "weak_rsa_key_size" => "CWE-326",
        crate::rules::USE_AFTER_FREE => "CWE-416",
        crate::rules::DOUBLE_FREE => "CWE-415",
        crate::rules::UNINITIALIZED_FREE => "CWE-908",
        crate::rules::BUFFER_OVERFLOW => "CWE-120",
        crate::rules::OUT_OF_BOUNDS_READ => "CWE-125",
        crate::rules::OUT_OF_BOUNDS_ACCESS => "CWE-787",
        crate::rules::INTEGER_OVERFLOW_ALLOC => "CWE-190",
        crate::rules::MEMORY_LEAK => "CWE-401",
        "policy_open_redirect" => "CWE-601",
        _ => return None,
    })
}

/// Sanitizer strength: what kind of injection does this call defeat?
#[derive(Debug, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SanitizerKind {
    /// Completely removes taint (e.g. numeric coercion: `int(user_input)`).
    Full,
    /// Defeats HTML/XSS injection only.
    HtmlEscape,
    /// Defeats URL-based attacks only.
    UrlEncode,
    /// Parameterised query - defeats SQL injection only.
    SqlParameterize,
    /// NoSQL sanitization - defeats NoSQL injection only.
    NoSqlParameterize,
    /// Session-store accessor trust: `store.get(token)` returns a
    /// server-issued session object (undefined for unknown tokens), so
    /// identity fields read off the result are not attacker-controlled.
    /// Receiver-aware: only applies when the receiver root is a declared
    /// session store.
    SessionTrust,
    /// Path canonicalization - defeats path traversal only.
    PathNormalize,
}

impl SanitizerKind {
    #[must_use]
    pub fn slug(&self) -> &'static str {
        match self {
            Self::Full => "full",
            Self::HtmlEscape => "html_escape",
            Self::UrlEncode => "url_encode",
            Self::SqlParameterize => "sql_parameterize",
            Self::NoSqlParameterize => "nosql_parameterize",
            Self::SessionTrust => "session_trust",
            Self::PathNormalize => "path_normalize",
        }
    }

    #[must_use]
    pub fn from_slug(slug: &str) -> Option<Self> {
        match slug {
            "full" => Some(Self::Full),
            // Legacy dialect aliases: `DEFAULT_SANITIZER_KIND` ("encode")
            // and `ALLOWLIST_SANITIZER_KIND` ("allowlist") are the labels
            // `FactTable::from_config` and bundle-learned sanitizers emit.
            // Map them to Full so role-qualified evaluation sees a known
            // kind instead of falling through to the sink-agnostic path.
            "encode" | "allowlist" | "generic" => Some(Self::Full),
            // Anything else is a genuinely unknown slug. The role-
            // qualified evaluator (`is_sanitizer_effective_for_role`)
            // treats `None` as "no cut": an unrecognized label must
            // never silence a sink it was never proven to defeat
            // (residual #15). Producers that need an opaque full cut
            // must emit one of the aliases above.
            "html_escape" => Some(Self::HtmlEscape),
            "url_encode" => Some(Self::UrlEncode),
            "sql_parameterize" => Some(Self::SqlParameterize),
            "nosql_parameterize" => Some(Self::NoSqlParameterize),
            "session_trust" => Some(Self::SessionTrust),
            "path_normalize" => Some(Self::PathNormalize),
            _ => None,
        }
    }

    /// Determines whether this sanitizer defeats a sink with the specified role and optional label.
    #[must_use]
    pub fn defeats_role_and_label(&self, role: SinkRole, label: Option<&str>) -> bool {
        match self {
            Self::Full => true,
            Self::HtmlEscape => {
                matches!(role, SinkRole::Xss | SinkRole::Response)
            }
            Self::UrlEncode => {
                matches!(role, SinkRole::Response | SinkRole::Resource)
            }
            Self::SqlParameterize => label == Some("sql"),
            Self::NoSqlParameterize => label == Some("nosql"),
            Self::SessionTrust => true,
            Self::PathNormalize => matches!(role, SinkRole::Resource) || label == Some("traversal"),
        }
    }
}

/// Shape classification of a dataflow finding (mirrors the engine's
/// `FindingClass`, which cannot be referenced from this crate).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaintClass {
    /// Taint reaches a raw injection channel (SQL string, exec, redirect...).
    Injection,
    /// Taint controls a field of an identity-payload query object, an
    /// access-control concern.
    Idor,
}

/// Advisory metadata for one declared rule: a level plus message templates.
///
/// Templates use the placeholders `{rule}`, `{function}`, `{file}` and
/// `{line}`, substituted by [`RuleAdvisory::render`].
#[derive(Debug)]
pub struct RuleAdvisory {
    pub level: Severity,
    pub title: &'static str,
    pub impact: &'static str,
    pub improvement: &'static str,
    pub tag: &'static str,
}

impl RuleAdvisory {
    /// Substitute placeholders and return the rendered advisory parts.
    pub fn render(
        &self,
        rule: &str,
        function: &str,
        file: &str,
        line: u32,
    ) -> (Severity, String, String, String, &'static str) {
        let render = |template: &str| {
            template
                .replace("{rule}", rule)
                .replace("{function}", function)
                .replace("{file}", file)
                .replace("{line}", &line.to_string())
        };
        (
            self.level,
            render(self.title),
            render(self.impact),
            render(self.improvement),
            self.tag,
        )
    }
}

/// One rule id bound to its declared advisory metadata.
#[derive(Debug)]
pub struct RuleEntry {
    pub rule: &'static str,
    pub advisory: RuleAdvisory,
}

/// The cross-cutting fallback for a checker rule no language declares:
/// ranked Warning under the generic "Policy violation" shape.
pub fn generic_rule_advisory(
    rule: &str,
    function: &str,
    file: &str,
    line: u32,
) -> (Severity, String, String, String, &'static str) {
    (
        Severity::Warning,
        format!("Policy violation: {rule} ({function})"),
        format!("{rule} at {file}:{line}, insecure cryptographic/configuration choice."),
        format!(
            "Replace the weak primitive in `{function}` with a modern alternative \
             (bcrypt/argon2 for passwords, SHA-256+ for digests)."
        ),
        "policy",
    )
}

/// Substitute the standard placeholders plus every `{key}` param placeholder
/// in an observation template.
fn render_observation(
    template: &str,
    rule: &str,
    function: &str,
    file: &str,
    line: u32,
    params: &[(&'static str, String)],
) -> String {
    let mut out = template
        .replace("{rule}", rule)
        .replace("{function}", function)
        .replace("{file}", file)
        .replace("{line}", &line.to_string());
    for (key, value) in params {
        out = out.replace(&format!("{{{key}}}"), value);
    }
    out
}

/// Observation templates for the cross-cutting rules no language registry
/// owns the observation body for (crypto policy, memory safety). Each arm
/// guards on the params it needs so a finding without them falls through
/// to the generic shape instead of rendering unfilled placeholders.
/// Returns `None` for rule ids these templates do not cover (learned
/// bundle rule ids fall through to the generic shape).
fn builtin_observation(rule: &str, params: &[(&'static str, String)]) -> Option<&'static str> {
    let has = |key: &str| params.iter().any(|(k, _)| *k == key);
    Some(match rule {
        "weak_hash" if has("sel") => {
            "Weak hash primitive '{sel}' selected by `{callee}`, not acceptable \
             for passwords or security-sensitive digests (use bcrypt/argon2/scrypt \
             or SHA-256+)"
        }
        "weak_hash" if has("callee") => {
            "Weak hash function `{callee}`, not acceptable for passwords or \
             security-sensitive digests (use bcrypt/argon2/scrypt or SHA-256+)"
        }
        crate::rules::WEAK_HASH_WRAPPER if has("path") => {
            "Password hashing routed through opaque wrapper `{path}`, verify it \
             uses bcrypt/argon2/scrypt, not MD5/SHA-1"
        }
        "weak_rsa_key_size" if has("min_bits") => {
            "Weak key size passed to `{callee}`: provably below {min_bits} bits \
             (use >= {min_bits} bits for {kind})"
        }
        "insecure_jwt_algorithm" if has("sel") => {
            "Insecure configuration: `{callee}` called with insecure selector '{sel}'"
        }
        crate::rules::SUBSTRING_ALLOWLIST_GUARD if has("seg") => {
            "Allowlist validation uses substring containment `{seg}`, bypassable by \
             embedding an allowed URL inside an attacker host \
             (`https://evil.com?https://allowed`). Use exact-match or \
             parse-and-compare-origin instead."
        }
        crate::rules::CREDENTIAL_KDF_POLICY if has("seg") => {
            "Credential `{seg}` call receives a plaintext password, password storage \
             must use a memory-hard KDF (bcrypt/argon2/scrypt), not a fast digest \
             wrapper."
        }
        crate::rules::ALLOWLIST_DEFINITION_BYPASSABLE => {
            "Allowlist `{function}` is enforced by substring containment elsewhere in \
             the program, any URL embedding one of these entries passes the guard \
             (`https://evil.com?https://allowed`). Enforce origin-exact matching at \
             the guard."
        }
        crate::rules::OUT_OF_BOUNDS_ACCESS if has("index") => {
            "Out-of-bounds access: index {index} for buffer `{buffer}` is negative"
        }
        crate::rules::BUFFER_OVERFLOW if has("index") => {
            "Buffer overflow: index {index} exceeds buffer `{buffer}` capacity {capacity}"
        }
        crate::rules::BUFFER_OVERFLOW if has("size") => {
            "Buffer overflow: write size {size} exceeds destination buffer `{buffer}` \
             capacity {capacity}"
        }
        crate::rules::OUT_OF_BOUNDS_READ if has("index") => {
            "Out-of-bounds read: index {index} exceeds buffer `{buffer}` capacity {capacity}"
        }
        crate::rules::OUT_OF_BOUNDS_READ if has("size") => {
            "Out-of-bounds read: read size {size} exceeds source buffer `{buffer}` \
             capacity {capacity}"
        }
        crate::rules::USE_AFTER_FREE if has("name") => {
            "`{name}` is used after the memory it points to was freed \
             (free-then-use). Remove the use or the free."
        }
        crate::rules::DOUBLE_FREE if has("name") => {
            "`{name}` is freed twice (double-free). Remove the second \
             free or null the pointer after the first."
        }
        crate::rules::UNINITIALIZED_FREE if has("name") => {
            "`{name}` is freed without guaranteed initialization \
             (uninitialized pointer free). Initialize before use."
        }
        crate::rules::MEMORY_LEAK if has("alloc") => {
            "Memory leak: `{alloc}` result in `{function}` is never released, \
             returned, or stored before the function returns"
        }
        crate::rules::INTEGER_OVERFLOW_ALLOC if has("message") => {
            "{message}: `{lhs}` ({al}..{ah}) * `{rhs}` ({bl}..{bh}) can wrap past \
             {threshold}, undersizing the `{allocator}` result"
        }
        crate::rules::UNBOUNDED_NUMBER_SCHEMA if has("text") => {
            "Schema declares a numeric policy in prose (`{text}`) but the builder \
             chain applies no `.max()`/`.min()` enforcement, the declared bound is \
             decorative. Add the constraint to the schema and validate in the handler."
        }
        _ => return None,
    })
}

/// Fallback observation for a checker rule no template covers: the rule id,
/// the location, and the finding's structured params, so learned bundle
/// rule ids still render an informative body.
pub fn generic_rule_observation(
    rule: &str,
    function: &str,
    file: &str,
    line: u32,
    params: &[(&'static str, String)],
) -> String {
    let mut out = format!("{rule} violated in `{function}` at {file}:{line}");
    if !params.is_empty() {
        let kv: Vec<String> = params.iter().map(|(k, v)| format!("{k}={v}")).collect();
        out.push_str(&format!(" ({})", kv.join(", ")));
    }
    out.push('.');
    out
}

/// Resolve advisory metadata for a checker finding: the language registry
/// first ([`crate::spec::LanguageSpec::known_rule_registry`]), the generic
/// policy fallback otherwise. The observation body renders from the
/// cross-cutting builtin templates (`builtin_observation`) keyed by rule
/// id and the finding's structured `params`, falling back to
/// [`generic_rule_observation`].
pub fn checker_advisory(
    spec: Option<&dyn crate::spec::LanguageSpec>,
    rule: &str,
    function: &str,
    file: &str,
    line: u32,
    params: &[(&'static str, String)],
) -> (Severity, String, String, String, &'static str, String) {
    let (level, title, impact, improvement, tag) = if let Some(spec) = spec {
        if let Some(entry) = spec.known_rule_registry().iter().find(|e| e.rule == rule) {
            entry.advisory.render(rule, function, file, line)
        } else {
            generic_rule_advisory(rule, function, file, line)
        }
    } else {
        generic_rule_advisory(rule, function, file, line)
    };
    let observation = match builtin_observation(rule, params) {
        Some(template) => render_observation(template, rule, function, file, line, params),
        None => generic_rule_observation(rule, function, file, line, params),
    };
    (level, title, impact, improvement, tag, observation)
}

/// Cross-cutting ranking for dataflow findings: what the sink does with the
/// data (role level) decides the default level; the shape class (Idor) can
/// only lower it further.
pub fn taint_advisory(
    class: TaintClass,
    role_level: Severity,
    role_tag: &str,
    sink: &str,
    src: &str,
) -> (Severity, String) {
    match (class, role_level) {
        // Access-control query payloads: ranked by role, retitled.
        (TaintClass::Idor, Severity::Critical) => (
            Severity::Warning,
            format!("User-controlled query field in `{sink}` (access-control review)"),
        ),
        // Response/validation sinks: review-level regardless of shape.
        (_, Severity::Info) => {
            let class_desc = match class {
                TaintClass::Idor => "as a query field",
                TaintClass::Injection => "as a value",
            };
            (
                Severity::Info,
                format!("User data reaches `{sink}` {class_desc} (review: role={role_tag})"),
            )
        }
        (_, level) => (
            level,
            format!("Unsanitized data from `{src}` reaches sink `{sink}`"),
        ),
    }
}

#[cfg(test)]
mod checker_observation_tests {
    use super::checker_advisory;

    fn observation(rule: &str, params: &[(&'static str, String)]) -> String {
        checker_advisory(None, rule, "handler", "a.ts", 7, params).5
    }

    #[test]
    fn weak_hash_selector_shape_renders_selected_primitive() {
        let obs = observation(
            "weak_hash",
            &[("callee", "createHash".into()), ("sel", "md5".into())],
        );
        assert_eq!(
            obs,
            "Weak hash primitive 'md5' selected by `createHash`, not acceptable \
             for passwords or security-sensitive digests (use bcrypt/argon2/scrypt \
             or SHA-256+)"
        );
    }

    #[test]
    fn weak_hash_bare_shape_renders_bare_call() {
        let obs = observation("weak_hash", &[("callee", "md5".into())]);
        assert_eq!(
            obs,
            "Weak hash function `md5`, not acceptable for passwords or \
             security-sensitive digests (use bcrypt/argon2/scrypt or SHA-256+)"
        );
    }

    #[test]
    fn weak_hash_wrapper_and_key_size_render_params() {
        let wrapper = observation("weak_hash_wrapper", &[("path", "vault.hash".into())]);
        assert_eq!(
            wrapper,
            "Password hashing routed through opaque wrapper `vault.hash`, verify it \
             uses bcrypt/argon2/scrypt, not MD5/SHA-1"
        );
        let key = observation(
            "weak_rsa_key_size",
            &[
                ("callee", "generateKey".into()),
                ("min_bits", "128".into()),
                ("kind", "symmetric keys".into()),
            ],
        );
        assert_eq!(
            key,
            "Weak key size passed to `generateKey`: provably below 128 bits \
             (use >= 128 bits for symmetric keys)"
        );
    }

    #[test]
    fn insecure_config_selector_renders_literal() {
        let obs = observation(
            "insecure_jwt_algorithm",
            &[("callee", "jwt".into()), ("sel", "none".into())],
        );
        assert_eq!(
            obs,
            "Insecure configuration: `jwt` called with insecure selector 'none'"
        );
    }

    #[test]
    fn unknown_rule_ids_fall_back_to_generic_observation_with_params() {
        let obs = observation(
            "learned_md5_policy",
            &[("callee", "createHash".into()), ("sel", "md5".into())],
        );
        assert_eq!(
            obs,
            "learned_md5_policy violated in `handler` at a.ts:7 \
             (callee=createHash, sel=md5)."
        );
    }

    #[test]
    fn guard_rules_render_verbatim_prose() {
        let seg = &[("seg", "includes".into())];
        assert_eq!(
            observation(crate::rules::SUBSTRING_ALLOWLIST_GUARD, seg),
            "Allowlist validation uses substring containment `includes`, bypassable by \
             embedding an allowed URL inside an attacker host \
             (`https://evil.com?https://allowed`). Use exact-match or \
             parse-and-compare-origin instead."
        );
        assert_eq!(
            observation(
                crate::rules::CREDENTIAL_KDF_POLICY,
                &[("seg", "hash".into())]
            ),
            "Credential `hash` call receives a plaintext password, password storage \
             must use a memory-hard KDF (bcrypt/argon2/scrypt), not a fast digest \
             wrapper."
        );
        assert_eq!(
            observation(crate::rules::ALLOWLIST_DEFINITION_BYPASSABLE, &[]),
            "Allowlist `handler` is enforced by substring containment elsewhere in \
             the program, any URL embedding one of these entries passes the guard \
             (`https://evil.com?https://allowed`). Enforce origin-exact matching at \
             the guard."
        );
    }

    #[test]
    fn memory_safety_templates_render_params() {
        let name = &[("name", "p".into())];
        assert_eq!(
            observation(crate::rules::USE_AFTER_FREE, name),
            "`p` is used after the memory it points to was freed \
             (free-then-use). Remove the use or the free."
        );
        assert_eq!(
            observation(crate::rules::DOUBLE_FREE, name),
            "`p` is freed twice (double-free). Remove the second \
             free or null the pointer after the first."
        );
        assert_eq!(
            observation(crate::rules::UNINITIALIZED_FREE, name),
            "`p` is freed without guaranteed initialization \
             (uninitialized pointer free). Initialize before use."
        );
        let leak = &[("alloc", "p".into())];
        assert_eq!(
            observation(crate::rules::MEMORY_LEAK, leak),
            "Memory leak: `p` result in `handler` is never released, \
             returned, or stored before the function returns"
        );
    }

    #[test]
    fn out_of_bounds_templates_pick_shape_by_params() {
        let index = &[
            ("index", "[0, 3]".into()),
            ("buffer", "data".into()),
            ("capacity", "[0, 7]".into()),
        ];
        assert_eq!(
            observation(crate::rules::OUT_OF_BOUNDS_ACCESS, index),
            "Out-of-bounds access: index [0, 3] for buffer `data` is negative"
        );
        assert_eq!(
            observation(crate::rules::BUFFER_OVERFLOW, index),
            "Buffer overflow: index [0, 3] exceeds buffer `data` capacity [0, 7]"
        );
        assert_eq!(
            observation(crate::rules::OUT_OF_BOUNDS_READ, index),
            "Out-of-bounds read: index [0, 3] exceeds buffer `data` capacity [0, 7]"
        );
        let size = &[
            ("size", "[0, 63]".into()),
            ("buffer", "dst".into()),
            ("capacity", "[0, 7]".into()),
        ];
        assert_eq!(
            observation(crate::rules::BUFFER_OVERFLOW, size),
            "Buffer overflow: write size [0, 63] exceeds destination buffer `dst` \
             capacity [0, 7]"
        );
        assert_eq!(
            observation(crate::rules::OUT_OF_BOUNDS_READ, size),
            "Out-of-bounds read: read size [0, 63] exceeds source buffer `dst` \
             capacity [0, 7]"
        );
    }

    #[test]
    fn integer_overflow_and_schema_templates_render_params() {
        let ovf = &[
            ("message", "Allocation size overflow".into()),
            ("lhs", "count".into()),
            ("al", "0".into()),
            ("ah", "8".into()),
            ("rhs", "size".into()),
            ("bl", "0".into()),
            ("bh", "9223372036854775807".into()),
            ("threshold", "18446744073709551615".into()),
            ("allocator", "buf".into()),
        ];
        assert_eq!(
            observation(crate::rules::INTEGER_OVERFLOW_ALLOC, ovf),
            "Allocation size overflow: `count` (0..8) * `size` (0..9223372036854775807) \
             can wrap past 18446744073709551615, undersizing the `buf` result"
        );
        assert_eq!(
            observation(
                crate::rules::UNBOUNDED_NUMBER_SCHEMA,
                &[("text", "maximum 10 percent".into())]
            ),
            "Schema declares a numeric policy in prose (`maximum 10 percent`) but the \
             builder chain applies no `.max()`/`.min()` enforcement, the declared bound \
             is decorative. Add the constraint to the schema and validate in the handler."
        );
    }

    #[test]
    fn registry_rules_keep_their_advisory_and_use_generic_observation() {
        let path = std::path::Path::new("a.c");
        let spec = crate::spec_for_path(path);
        let (level, title, _, _, _, obs) =
            checker_advisory(spec, crate::rules::BUFFER_OVERFLOW, "f", "a.c", 3, &[]);
        assert_eq!(level, super::Severity::Critical);
        assert_eq!(title, "Memory safety violation: buffer_overflow (f)");
        assert_eq!(obs, "buffer_overflow violated in `f` at a.c:3.");
    }
}

#[cfg(test)]
mod cwe_mapping_tests {
    use super::{checker_rule_cwe, taint_cwe, SinkRole};

    #[test]
    fn taint_role_and_label_pin_the_cwe() {
        assert_eq!(taint_cwe(SinkRole::Xss, None), Some("CWE-79"));
        assert_eq!(taint_cwe(SinkRole::Execution, Some("sql")), Some("CWE-89"));
        assert_eq!(
            taint_cwe(SinkRole::Execution, Some("command")),
            Some("CWE-78")
        );
        assert_eq!(
            taint_cwe(SinkRole::Execution, Some("deserialize")),
            Some("CWE-502")
        );
        assert_eq!(
            taint_cwe(SinkRole::Resource, Some("traversal")),
            Some("CWE-22")
        );
        assert_eq!(
            taint_cwe(SinkRole::Response, Some("redirect")),
            Some("CWE-601")
        );
    }

    #[test]
    fn ambiguous_roles_stay_untagged() {
        assert_eq!(
            taint_cwe(SinkRole::Execution, None),
            None,
            "bare execution spans command/SQL/code injection"
        );
        assert_eq!(
            taint_cwe(SinkRole::Resource, None),
            None,
            "resource spans traversal and IDOR-class queries"
        );
        assert_eq!(taint_cwe(SinkRole::Storage, None), None);
        assert_eq!(taint_cwe(SinkRole::Validation, None), None);
        assert_eq!(taint_cwe(SinkRole::Other, None), None);
    }

    #[test]
    fn checker_rules_map_to_their_canonical_cwe() {
        assert_eq!(checker_rule_cwe("weak_hash"), Some("CWE-328"));
        assert_eq!(
            checker_rule_cwe(crate::rules::WEAK_HASH_WRAPPER),
            Some("CWE-328")
        );
        assert_eq!(
            checker_rule_cwe(crate::rules::USE_AFTER_FREE),
            Some("CWE-416")
        );
        assert_eq!(checker_rule_cwe(crate::rules::MEMORY_LEAK), Some("CWE-401"));
        assert_eq!(
            checker_rule_cwe("policy_custom_rule"),
            None,
            "learned rules take their CWE from the bundle pattern overlay"
        );
    }
}
