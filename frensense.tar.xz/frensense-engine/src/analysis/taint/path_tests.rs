// SPDX-License-Identifier: GPL-3.0-only
// Copyright (c) 2024-2026 Friehub. All rights reserved.
// Commercial use requires a separate license: https://friehub.com/licensing

//! Tests for taint-path capture (R3c).

#[cfg(test)]
mod path_capture_tests {
    use crate::analysis::forward::ProgramSvfg;
    use crate::analysis::taint::config::TaintConfig;
    use crate::analysis::taint::engine::{BackwardTaintEngine, BackwardVerdict};
    use crate::analysis::taint::path::{PathStep, dedup_by_shape};
    use crate::harness::lower_source;
    use crate::ir::function::FunctionIR;
    use rustc_hash::FxHashMap;

    const CROSS_FILE: &str = r#"
import { Pool } from "pg";
const pool = new Pool();

function buildQuery(id: string): string {
  return "SELECT * FROM users WHERE id = '" + id + "'";
}

function handler(req: any): void {
  const q = buildQuery(req.body.id);
  pool.query(q);
}
"#;

    fn run(src: &str) -> Vec<super::super::engine::SinkFinding> {
        let fns = lower_source("t.ts", src, "ts").expect("lower");
        let owned: Vec<FunctionIR> = fns.into_values().collect();
        let mut statics: FxHashMap<String, &FunctionIR> = FxHashMap::default();
        for ir in &owned {
            statics.insert(ir.name.clone(), ir);
        }
        let mut config = TaintConfig::default();
        config.sinks.insert("query".into());
        config.sources.insert("req.body".into());
        config.sources.insert("req".into());
        let prog = ProgramSvfg::new(&statics, &config);
        let mut engine = BackwardTaintEngine::new(&prog, &config);
        engine.run();
        engine.findings
    }

    #[test]
    fn interprocedural_path_source_to_sink() {
        let findings = run(CROSS_FILE);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable)
            .collect();
        assert!(!vuln.is_empty(), "probe must produce a vulnerable finding");

        let p = &vuln[0].path;
        // First step describes the source.
        assert!(
            matches!(&p.steps[0], PathStep::Source { description } if description.contains("req.body")),
            "first step must be the source, got {:?}",
            p.steps[0]
        );
        // The path crosses into buildQuery and returns.
        assert!(
            p.steps.iter().any(
                |s| matches!(s, PathStep::CallReturn { callee, .. } if callee == "buildQuery")
            ),
            "path must include the call-return hop, got {p:?}"
        );
        assert!(
            p.steps.iter().any(
                |s| matches!(s, PathStep::FormalParam { function, .. } if function == "buildQuery")
            ),
            "path must include entering the callee as a parameter"
        );
        // Source-first ordering.
        assert!(p.steps.len() >= 3, "path should have multiple steps");
        assert_eq!(p.spans.len(), p.steps.len(), "spans must align with steps");
    }

    #[test]
    fn non_vulnerable_findings_have_empty_path() {
        let findings = run(CROSS_FILE);
        for f in &findings {
            if f.verdict != BackwardVerdict::Vulnerable {
                assert!(
                    f.path.steps.is_empty(),
                    "non-vulnerable findings must not carry a path"
                );
            }
        }
    }

    #[test]
    fn same_shape_dedups_to_one() {
        let findings = run(CROSS_FILE);
        let paths: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable)
            .map(|f| f.path.clone())
            .collect();
        // Identical shape paths (same flow reported once) dedup to one.
        let kept = dedup_by_shape(&paths);
        assert!(!kept.is_empty());
        // Deduping a single path returns itself.
        assert_eq!(kept.len(), 1);
    }

    #[test]
    fn shape_id_ignores_variable_numbering() {
        let a = super::super::path::TaintPath {
            steps: vec![
                PathStep::Source {
                    description: "req.body".into(),
                },
                PathStep::Assignment {
                    function: "f".into(),
                    variable: 7,
                },
            ],
            spans: vec![None, None],
        };
        let b = super::super::path::TaintPath {
            steps: vec![
                PathStep::Source {
                    description: "req.body".into(),
                },
                PathStep::Assignment {
                    function: "f".into(),
                    variable: 99,
                },
            ],
            spans: vec![None, None],
        };
        assert_eq!(a.shape_id(), b.shape_id());
    }
}

#[cfg(test)]
mod idor_classification_tests {
    use crate::analysis::forward::ProgramSvfg;
    use crate::analysis::taint::config::TaintConfig;
    use crate::analysis::taint::engine::{BackwardTaintEngine, BackwardVerdict, FindingClass};
    use crate::harness::lower_source;
    use crate::ir::function::FunctionIR;
    use rustc_hash::FxHashMap;

    fn run(src: &str) -> Vec<crate::analysis::taint::engine::SinkFinding> {
        let fns = lower_source("t.ts", src, "ts").expect("lower");
        let owned: Vec<FunctionIR> = fns.into_values().collect();
        let mut statics: FxHashMap<String, &FunctionIR> = FxHashMap::default();
        for ir in &owned {
            statics.insert(ir.name.clone(), ir);
        }
        let mut config = TaintConfig::default();
        config.sinks.insert("findOne".into());
        config.sinks.insert("query".into());
        config.sources.insert("req.body".into());
        config.sources.insert("req".into());
        let prog = ProgramSvfg::new(&statics, &config);
        let facts = crate::analysis::taint::facts::seeded_tables(["ts"]).1;
        let mut engine = BackwardTaintEngine::new(&prog, &config).with_fact_table(&facts);
        engine.run();
        engine.findings
    }

    /// `findOne({ where: { id: req.body.x } })`: `where` is a clause
    /// wrapper, not an identity key - the driver parameterizes the leaf
    /// value, nothing here proves which-record control. Not reported
    /// (zero-FP: structurally unprovable findings never fire).
    #[test]
    fn where_wrapped_clause_is_not_a_finding() {
        let src = r#"
export function updateProfile(req: any, db: any): void {
  db.User.findOne({ where: { id: req.body.userId } });
}
"#;
        let findings = run(src);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(
            vuln.is_empty(),
            "where-wrapped clause must not alert, got {:?}",
            vuln.iter()
                .map(|f| (&f.sink, f.finding_class))
                .collect::<Vec<_>>()
        );
    }

    /// `findOne({ _id: req.body.x })`: a top-level identity key marks the
    /// payload as which-record control → still reported as Idor.
    #[test]
    fn identity_payload_is_idor_class() {
        let src = r#"
export function updateProfile(req: any, db: any): void {
  db.User.findOne({ _id: req.body.userId });
}
"#;
        let findings = run(src);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(!vuln.is_empty(), "identity payload must be detected");
        assert!(
            vuln.iter().any(|f| f.finding_class == FindingClass::Idor),
            "identity-payload flow must classify as Idor, got {:?}",
            vuln.iter().map(|f| f.finding_class).collect::<Vec<_>>()
        );
    }

    /// Auth-guarded handler: an early-return branch over an auth-vocab call
    /// (`security.authenticatedUsers.from(req)` → `if (!user) return`)
    /// dominates the sink and has a rejecting path that never reaches it -
    /// the query only executes for authenticated callers, so the identity
    /// payload is not an access-control violation. Suppressed (Idor class
    /// only).
    #[test]
    fn auth_guarded_identity_payload_is_suppressed() {
        let src = r#"
export function likeReview(req: any, db: any): void {
  const user = security.authenticatedUsers.from(req);
  if (!user) {
    return;
  }
  db.Reviews.findOne({ _id: req.body.id });
}
"#;
        let findings = run(src);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(
            vuln.is_empty(),
            "auth-guarded identity query must be suppressed, got {:?}",
            vuln.iter()
                .map(|f| (&f.sink, f.finding_class))
                .collect::<Vec<_>>()
        );
    }

    /// Auth *presence* without a guard branch must NOT suppress: the forged
    /// review TP shape fetches `user` but queries before (or without) any
    /// auth check - the identity query is unguarded and stays reported.
    #[test]
    fn auth_call_without_guard_branch_still_reports() {
        let src = r#"
export function updateReview(req: any, db: any): void {
  const user = security.authenticatedUsers.from(req);
  db.Reviews.findOne({ _id: req.body.id });
  if (user) {
    audit(user);
  }
}
"#;
        let findings = run(src);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(
            vuln.iter().any(|f| f.finding_class == FindingClass::Idor),
            "unguarded identity query must still report as Idor, got {:?}",
            vuln.iter()
                .map(|f| (&f.sink, f.finding_class))
                .collect::<Vec<_>>()
        );
    }

    /// `query("SELECT..." + req.body.x)`, raw string concat → Injection.
    #[test]
    fn raw_string_is_injection_class() {
        let src = r#"
export function getUser(req: any, pool: any): void {
  pool.query("SELECT * FROM users WHERE id = '" + req.body.id + "'");
}
"#;
        let findings = run(src);
        let vuln: Vec<_> = findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(!vuln.is_empty(), "flow must be detected");
        assert!(
            vuln.iter()
                .all(|f| f.finding_class == FindingClass::Injection),
            "raw string flow must classify as Injection, got {:?}",
            vuln.iter().map(|f| f.finding_class).collect::<Vec<_>>()
        );
    }

    /// Custom taught IDOR finder sink and custom key: misses at baseline, detects as Idor with learned facts.
    #[test]
    fn custom_teachable_idor_finder_and_key() {
        let src = r#"
export function getAccount(req: any, repo: any): void {
  repo.fetchRecord({ org_identifier: req.body.orgId });
}
"#;
        // 1. Baseline: fetchRecord is unknown, 0 findings
        let baseline_findings = run(src);
        let baseline_vuln: Vec<_> = baseline_findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();
        assert!(
            baseline_vuln.is_empty(),
            "custom sink must not alert at baseline"
        );

        // 2. With learned IDOR finder sink and custom key
        let files = vec![("test.ts".to_string(), src.to_string(), "ts".to_string())];
        let mut facts = crate::analysis::taint::facts::seeded_tables(["ts"]).1;
        let fact = crate::analysis::taint::facts::LearnedFactEntry::IdorFinderSink {
            call: "fetchRecord".to_string(),
            keys: vec!["org_identifier".to_string()],
        };
        fact.apply(&mut facts);

        let mut sources = rustc_hash::FxHashSet::default();
        sources.insert("req.body".to_string());
        let config = TaintConfig {
            sources,
            sinks: rustc_hash::FxHashSet::default(),
            sanitizers: rustc_hash::FxHashSet::default(),
        };

        let res = crate::scan::scan(&files, &config, &facts);
        let taught_vuln: Vec<_> = res
            .findings
            .iter()
            .filter(|f| f.verdict == BackwardVerdict::Vulnerable && f.alert.is_some())
            .collect();

        assert!(
            !taught_vuln.is_empty(),
            "custom IDOR finder must alert with learned fact"
        );
        assert!(
            taught_vuln
                .iter()
                .any(|f| f.finding_class == FindingClass::Idor),
            "must classify as Idor finding class, got {:?}",
            taught_vuln
                .iter()
                .map(|f| f.finding_class)
                .collect::<Vec<_>>()
        );
    }
}
